#!/bin/sh

# Переменные не обязательны. Если пустые, отправка сообщения не осуществляется.

echo Enter your tgToken:
read tgToken
echo -e "Ваш токен: $tgToken"
echo Enter your tgChatId:
read tgChatId
echo -e "Ваш чат: $tgChatId"

initd_file="/opt/usr/bin/nfqws_var"
script_content='#!/bin/sh 
tgToken="'${tgToken}'"
tgChatId="'${tgChatId}'"
'
echo "Файл nfqws_var создан"	
        echo -e "${script_content}" > "${initd_file}" 
        chmod +x "${initd_file}"
		
# Функции
function sendTelegram {
  local tgUrl="https://api.telegram.org/bot$tgToken/sendMessage"
  local tgTimeout="10"
  local tgText="$@"
  local tgCmdArgs="parse_mode=HTML&chat_id=$tgChatId&disable_web_page_preview=1&text=$tgText"
  tgCmd=$(curl --max-time $tgTimeout -d "$tgCmdArgs" $tgUrl -s)
  if [ $? -gt 0 ]; then echo "Ошибка отправки Telegram"; else echo "Отправка сообщения Telegram Успешно!"; fi
}
