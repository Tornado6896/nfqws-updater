#!/bin/sh


 function choose_menu {
            echo
            echo "  Выберите пункт"
            echo "     1. Выберите время обновлений"
            echo "     2. Данные telegram"
            echo "     3. Выполниить обновление userlist и nfqws"
            echo "     3. Выход"
            echo

            local choice
            while true; do
                read -p "  Ваш выбор: " choice
                if [[ "$choice" =~ ^[0-8]$ ]]; then
                    break
                else
                    echo -e "  ${red}Некорректный номер действия.${reset} Пожалуйста, выберите снова"
                fi
            done

            if [ "$choice" -eq 1 ]; then
                echo -e "  Выберите время обновлений."
            nfqws_cron_time.sh
			else
              if [ "$choice" -eq 2 ]; then
                echo -e "  Данные telegram."
            nfqws_tg.sh
			else
			if [ "$choice" -eq 3 ]; then
                echo -e "  Обновление userlist и nfqws."
            nfqws_updater.sh
			else
			if [ "$choice" -eq 4 ]; then
                echo -e "  Выход"
			exit 0
			
		
}
#Скрипт

choose_menu;